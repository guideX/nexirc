﻿Option Explicit On
Option Strict On
Public Interface clsMdiChildWindow
    WriteOnly Property MeIndex() As Integer

End Interface
